// File: get-messages.ts
import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
serve(async (req)=>{
  // Only allow GET requests
  if (req.method !== "GET") {
    return new Response(JSON.stringify({
      error: "Method Not Allowed"
    }), {
      status: 405
    });
  }
  // Initialize Supabase client with Auth header from request
  const supabase = createClient(Deno.env.get("SUPABASE_URL"), Deno.env.get("SUPABASE_ANON_KEY"), {
    global: {
      headers: {
        Authorization: req.headers.get("Authorization")
      }
    }
  });
  // Get the authenticated user
  const { data: { user }, error: userError } = await supabase.auth.getUser();
  if (userError || !user) {
    return new Response(JSON.stringify({
      error: "Unauthorized"
    }), {
      status: 401
    });
  }
  // Fetch messages for the user
  const { data: messages, error: fetchError } = await supabase.from("messages").select("*").eq("user_id", user.id).order("created_at", {
    ascending: false
  });
  if (fetchError) {
    return new Response(JSON.stringify({
      error: fetchError.message
    }), {
      status: 500
    });
  }
  return new Response(JSON.stringify({
    messages
  }), {
    status: 200,
    headers: {
      "Content-Type": "application/json"
    }
  });
});
